package com.mohsindeveloper.gpacalculator;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.jaiselrahman.hintspinner.HintSpinner;
import com.jaiselrahman.hintspinner.HintSpinnerAdapter;

import java.util.Collections;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends BaseFragment{


    public HomeFragment() {
        // Required empty public constructor
    }


    EditText etGrade1;
    EditText etGrade2;
    EditText etGrade3;
    EditText etGrade4;
    EditText etGrade5;
    EditText etCrh1;
    EditText etCrh2;
    EditText etCrh3;
    EditText etCrh4;
    EditText etCrh5;
    TextView computeGpa;

    String subjectOneGrade = "";
    String subjectTwoGrade = "";
    String subjectThreeGrade = "";
    String subjectFourGrade = "";
    String subjectFiveGrade = "";
    String creditHour1 = "";
    String creditHour2 = "";
    String creditHour3 = "";
    String creditHour4 = "";
    String creditHour5 = "";



    ///////////////////subject values assign
    int subjectGradeValue1 = 0;
    int subjectGradeValue2 = 0;
    int subjectGradeValue3 = 0;
    int subjectGradeValue4 = 0;
    int subjectGradeValue5 = 0;

    int crhValue1 = 0;
    int crhValue2 = 0;
    int crhValue3 = 0;
    int crhValue4 = 0;
    int crhValue5 = 0;


    int totalCrh = 0;

    double subjectGradesCal = 0;

    int sumGrade1 = 0;
    int sumGrade2 = 0;
    int sumGrade3 = 0;
    int sumGrade4 = 0;
    int sumGrade5 = 0;

    int allSumOfGrades = 0;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etGrade1 = view.findViewById(R.id.etGrade1);
        etGrade2 = view.findViewById(R.id.etGrade2);
        etGrade3 = view.findViewById(R.id.etGrade3);
        etGrade4 = view.findViewById(R.id.etGrade4);
        etGrade5 = view.findViewById(R.id.etGrade5);

        etCrh1 = view.findViewById(R.id.etCreditHr1);
        etCrh2 = view.findViewById(R.id.etCreditHr2);
        etCrh3 = view.findViewById(R.id.etCreditHr3);
        etCrh4 = view.findViewById(R.id.etCreditHr4);
        etCrh5 = view.findViewById(R.id.etCreditHr5);

        computeGpa = view.findViewById(R.id.computeGpa);


        clickEvents();


    }

    public void clickEvents(){
        computeGpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validation();

            }
        });
    }

    public void validation(){

        subjectOneGrade = etGrade1.getText().toString();
        subjectTwoGrade = etGrade2.getText().toString();
        subjectThreeGrade = etGrade3.getText().toString();
        subjectFourGrade = etGrade4.getText().toString();
        subjectFiveGrade = etGrade5.getText().toString();


        creditHour1 = etCrh1.getText().toString();
        creditHour2 = etCrh2.getText().toString();
        creditHour3 = etCrh3.getText().toString();
        creditHour4 = etCrh4.getText().toString();
        creditHour5 = etCrh5.getText().toString();

        if (subjectOneGrade.isEmpty()){
            etGrade1.setError("Please Enter Your Grade");
        }else if(creditHour1.isEmpty()){
            etCrh1.setError("Please Enter Subject Credit hour");
        }else if (subjectTwoGrade.isEmpty()){
            etGrade2.setError("Please Enter Your Grade");
        }else if(creditHour2.isEmpty()){
            etCrh2.setError("Please Enter Subject Credit hour");
        }else if (subjectThreeGrade.isEmpty()){
            etGrade3.setError("Please Enter Your Grade");
        }else if(creditHour3.isEmpty()){
            etCrh3.setError("Please Enter Subject Credit hour");
        }else if (subjectFourGrade.isEmpty()){
            etGrade4.setError("Please Enter Your Grade");
        }else if(creditHour4.isEmpty()){
            etCrh4.setError("Please Enter Subject Credit hour");
        }else if (subjectFiveGrade.isEmpty()){
            etGrade5.setError("Please Enter Your Grade");
        }else if(creditHour5.isEmpty()){
            etCrh5.setError("Please Enter Subject Credit hour");
        }else{


            getValuesToCalculateGpa();


        }
    }

    public void getValuesToCalculateGpa(){

        if (subjectOneGrade.toUpperCase().equals("A")){
            subjectGradeValue1 = 4;
        }else if (subjectOneGrade.toUpperCase().equals("B")){
            subjectGradeValue1 = 3;
        }else if (subjectOneGrade.toUpperCase().equals("C")){
            subjectGradeValue1 = 2;
        }else if (subjectOneGrade.toUpperCase().equals("D")){
            subjectGradeValue1 = 1;
        }else if(subjectOneGrade.toUpperCase().equals("F")){
            subjectGradeValue1 = 0;
        }

        if (creditHour1.equals("1")){
            crhValue1 = 1;
        }else if(creditHour1.equals("2")){
            crhValue1 = 2;

        }else if (creditHour1.equals("3")){
            crhValue1 = 3;

        }else if (creditHour1.equals("4")){
            crhValue1 = 4;

        }

        if (subjectTwoGrade.toUpperCase().equals("A")){
            subjectGradeValue2 = 4;
        }else if (subjectTwoGrade.toUpperCase().equals("B")){
            subjectGradeValue2 = 3;
        }else if (subjectTwoGrade.toUpperCase().equals("C")){
            subjectGradeValue2 = 2;
        }else if (subjectTwoGrade.toUpperCase().equals("D")){
            subjectGradeValue2 = 1;
        }else if(subjectTwoGrade.toUpperCase().equals("F")){
            subjectGradeValue2 = 0;
        }

        if (creditHour2.equals("1")){
            crhValue2 = 1;
        }else if(creditHour2.equals("2")){
            crhValue2 = 2;

        }else if (creditHour2.equals("3")){
            crhValue2 = 3;

        }else if (creditHour2.equals("4")){
            crhValue2 = 4;

        }

        if (subjectThreeGrade.toUpperCase().equals("A")){
            subjectGradeValue3 = 4;
        }else if (subjectThreeGrade.toUpperCase().equals("B")){
            subjectGradeValue3 = 3;
        }else if (subjectThreeGrade.toUpperCase().equals("C")){
            subjectGradeValue3 = 2;
        }else if (subjectThreeGrade.toUpperCase().equals("D")){
            subjectGradeValue3 = 1;
        }else if(subjectThreeGrade.toUpperCase().equals("F")){
            subjectGradeValue3 = 0;
        }

        if (creditHour3.equals("1")){
            crhValue3 = 1;
        }else if(creditHour3.equals("2")){
            crhValue3 = 2;

        }else if (creditHour3.equals("3")){
            crhValue3 = 3;

        }else if (creditHour3.equals("4")){
            crhValue3 = 4;

        }

        if (subjectFourGrade.toUpperCase().equals("A")){
            subjectGradeValue4 = 4;
        }else if (subjectFourGrade.toUpperCase().equals("B")){
            subjectGradeValue4 = 3;
        }else if (subjectFourGrade.toUpperCase().equals("C")){
            subjectGradeValue4 = 2;
        }else if (subjectFourGrade.toUpperCase().equals("D")){
            subjectGradeValue4 = 1;
        }else if(subjectFourGrade.toUpperCase().equals("F")){
            subjectGradeValue4 = 0;
        }

        if (creditHour4.equals("1")){
            crhValue4 = 1;
        }else if(creditHour4.equals("2")){
            crhValue4 = 2;

        }else if (creditHour4.equals("3")){
            crhValue4 = 3;

        }else if (creditHour4.equals("4")){
            crhValue4 = 4;

        }

        if (subjectFiveGrade.toUpperCase().equals("A")){
            subjectGradeValue5 = 4;
        }else if (subjectFiveGrade.toUpperCase().equals("B")){
            subjectGradeValue5 = 3;
        }else if (subjectFiveGrade.toUpperCase().equals("C")){
            subjectGradeValue5 = 2;
        }else if (subjectFiveGrade.toUpperCase().equals("D")){
            subjectGradeValue5 = 1;
        }else if(subjectFiveGrade.toUpperCase().equals("F")){
            subjectGradeValue5 = 0;
        }

        if (creditHour5.equals("1")){
            crhValue5 = 1;
        }else if(creditHour5.equals("2")){
            crhValue5 = 2;

        }else if (creditHour5.equals("3")){
            crhValue5 = 3;

        }else if (creditHour5.equals("4")){
            crhValue5 = 4;

        }

        totalCrh = crhValue1 + crhValue2 + crhValue3 +crhValue4 + crhValue5;

        sumGrade1 = subjectGradeValue1 * crhValue1;
        sumGrade2 = subjectGradeValue2 * crhValue2;
        sumGrade3 = subjectGradeValue3 * crhValue3;
        sumGrade4 = subjectGradeValue4 * crhValue4;
        sumGrade5 = subjectGradeValue5 * crhValue5;

        allSumOfGrades = sumGrade1 + sumGrade2 + sumGrade3 + sumGrade4 + sumGrade5;

        subjectGradesCal = (double) allSumOfGrades / totalCrh;

        Log.d("totalCrh" , String.valueOf(subjectGradesCal));


        ShowGpaFragment ldf = new ShowGpaFragment ();
        Bundle args = new Bundle();
        args.putString("gpa", String.valueOf(subjectGradesCal));
        ldf.setArguments(args);

        Intent intent = new Intent(getContext(), ShowGpaActivityActivity.class);
        intent.putExtra("gpa", String.valueOf(subjectGradesCal));
        startActivity(intent);

//        changeFragment(new ShowGpaFragment());

    }


}
