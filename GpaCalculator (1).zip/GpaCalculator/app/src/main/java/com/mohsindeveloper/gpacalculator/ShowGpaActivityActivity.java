package com.mohsindeveloper.gpacalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ShowGpaActivityActivity extends BaseActivity {


    String cgpaValue = "";
    TextView cgpaText;
    LinearLayout mainLayout;
    Double cgpa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_gpa_activity);


        Intent intent = getIntent();

        cgpaValue = intent.getStringExtra("gpa");

        cgpaText = findViewById(R.id.tvCgpa);
        mainLayout = findViewById(R.id.main_layout);



        cgpa = Double.valueOf(cgpaValue);

        if (cgpa >= 3.25){
            mainLayout.setBackgroundColor(Color.parseColor("#26E22D"));
        }else if (cgpa < 3.25 && cgpa >= 2.25){
            mainLayout.setBackgroundColor(Color.parseColor("#FCEB51"));
        }else if (cgpa < 2.25){
            mainLayout.setBackgroundColor(Color.parseColor("#F3594E"));

        }

        cgpaText.setText(cgpaValue);
    }
}
