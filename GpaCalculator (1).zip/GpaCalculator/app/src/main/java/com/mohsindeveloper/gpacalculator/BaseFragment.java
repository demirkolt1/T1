package com.mohsindeveloper.gpacalculator;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class BaseFragment extends Fragment {

    public void changeFragment(Fragment fragment) {
        FragmentManager manager = getActivity().getSupportFragmentManager();
        manager.beginTransaction().replace(R.id.fragment_container, fragment).commit();
    }
}
