package com.mohsindeveloper.gpacalculator;


import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ShowGpaFragment extends BaseFragment {


    public ShowGpaFragment() {
        // Required empty public constructor
    }

    String cgpaValue = "";
    TextView cgpaText;
    LinearLayout mainLayout;
    Double cgpa;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_show_gpa, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cgpaText = view.findViewById(R.id.tvCgpa);
        mainLayout = view.findViewById(R.id.main_layout);


        Bundle bundle= new Bundle();

        cgpaValue = savedInstanceState.getString("gpa");

        cgpa = Double.valueOf(cgpaValue);

        if (cgpa >= 3.25){
            mainLayout.setBackgroundColor(Color.parseColor("#26E22D"));
        }else if (cgpa < 3.25 && cgpa >= 2.25){
            mainLayout.setBackgroundColor(Color.parseColor("#FCEB51"));
        }else if (cgpa < 2.25){
            mainLayout.setBackgroundColor(Color.parseColor("#F3594E"));

        }

        cgpaText.setText(cgpaValue);

    }
}
