package com.lunaticaliens.courseregistrationapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * The type User adapter.
 */
public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private Context context;
    private ArrayList<User> adapterData;
    private LayoutInflater mInflater;

    // click listener
    private ItemClickListener mClickListener;

    /**
     * Instantiates a new User adapter.
     *
     * @param context the context
     * @param data    the data
     */
    public UserAdapter(Context context, ArrayList<User> data) {
        this.context = context;
        this.mInflater = LayoutInflater.from(context);
        this.adapterData = data;
    }

    @NonNull
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.row_users, parent, false);
        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final UserAdapter.ViewHolder holder, int position) {

        holder.nameTextView.setText("Name: " + adapterData.get(position).getName());
        holder.emailTextView.setText("Email: " + adapterData.get(position).getEmail());
        holder.priorityTextView.setText("Priority: " + adapterData.get(position).getPriority());
    }

    /**
     * Sets click listener.
     *
     * @param itemClickListener the item click listener
     */
    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    @Override
    public int getItemCount() {
        if (adapterData != null)
            return adapterData.size();
        else return 0;
    }

    /**
     * The interface Item click listener.
     */
    public interface ItemClickListener {
        /**
         * On item click.
         *
         * @param view     the view
         * @param position the position
         */
        void onItemClick(View view, int position);
    }

    /**
     * Sets adapter data.
     *
     * @param adapterData the adapter data
     */
    public void setAdapterData(ArrayList<User> adapterData) {
        this.adapterData = adapterData;
    }

    /**
     * Gets item.
     *
     * @param id the id
     * @return the item
     */
    public User getItem(int id) {
        return adapterData.get(id);
    }

    /**
     * The type View holder.
     */
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        /**
         * The Name text view.
         */
        TextView nameTextView;
        /**
         * The Email text view.
         */
        TextView emailTextView;
        /**
         * The Priority text view.
         */
        TextView priorityTextView;

        /**
         * The Edit button.
         */
        Button editButton;
        /**
         * The Delete button.
         */
        Button deleteButton;


        /**
         * Instantiates a new View holder.
         *
         * @param itemView the item view
         */
        ViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.tv_name);
            emailTextView = itemView.findViewById(R.id.tv_email);
            priorityTextView = itemView.findViewById(R.id.tv_priority);

            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);

            editButton.setOnClickListener(this);
            deleteButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }
}
