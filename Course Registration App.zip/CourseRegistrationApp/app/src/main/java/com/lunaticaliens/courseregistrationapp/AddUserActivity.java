package com.lunaticaliens.courseregistrationapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * The type Add user activity.
 */
public class AddUserActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText priorityEditText;
    private EditText emailEditText;
    private EditText nameEditText;

    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        priorityEditText = findViewById(R.id.et_priority);
        emailEditText = findViewById(R.id.et_email);
        nameEditText = findViewById(R.id.et_name);

        saveButton = findViewById(R.id.btn_save);
        saveButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == saveButton) {
            String priority = priorityEditText.getText().toString().trim();
            String email = nameEditText.getText().toString().trim();
            String name = emailEditText.getText().toString().trim();

            if (!priority.isEmpty() && !email.isEmpty() && !name.isEmpty()) {
                User user = new User(priority, email, name);
                DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                databaseHelper.addUser(user);
                Toast.makeText(this, "saved", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

            } else {
                Toast.makeText(this, "error occurred", Toast.LENGTH_SHORT).show();

            }
        }
    }
}
