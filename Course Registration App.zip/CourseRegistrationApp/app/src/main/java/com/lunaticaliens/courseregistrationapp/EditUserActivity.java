package com.lunaticaliens.courseregistrationapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * The type Edit user activity.
 */
public class EditUserActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText priorityEditText;
    private EditText emailEditText;
    private EditText nameEditText;

    private Button editButton;

    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        user = (User) getIntent().getSerializableExtra("OBJ");

        priorityEditText = findViewById(R.id.et_name);
        emailEditText = findViewById(R.id.et_email);
        nameEditText = findViewById(R.id.et_priority);

        priorityEditText.setText(user.getPriority());
        emailEditText.setText(user.getEmail());
        nameEditText.setText(user.getName());

        editButton = findViewById(R.id.btn_edit);
        editButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == editButton) {
            String priority = priorityEditText.getText().toString().trim();
            String email = emailEditText.getText().toString().trim();
            String name = nameEditText.getText().toString().trim();


            if (!priority.isEmpty() && !email.isEmpty() && !name.isEmpty()) {
                DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                user.setEmail(email);
                user.setPriority(priority);
                user.setName(name);

                databaseHelper.updateUser(user);
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

            } else {
                Toast.makeText(this, "error occurred", Toast.LENGTH_SHORT).show();

            }
        }
    }
}
