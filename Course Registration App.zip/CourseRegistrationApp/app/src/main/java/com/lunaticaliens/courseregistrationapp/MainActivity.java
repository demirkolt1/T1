package com.lunaticaliens.courseregistrationapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

/**
 * The type Main activity.
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener, UserAdapter.ItemClickListener {


    private static final String TAG = "MainActivity";

    private RecyclerView usersRecyclerView;
    private FloatingActionButton addFloatingActionButton;

    private UserAdapter userAdapter;
    private DatabaseHelper databaseHelper;

    private ArrayList<User> userArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(getApplicationContext());
        userArrayList = new ArrayList<>();
        userArrayList = databaseHelper.getAllUser();

        usersRecyclerView = findViewById(R.id.rv_users);
        usersRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        userAdapter = new UserAdapter(getApplicationContext(), databaseHelper.getAllUser());
        userAdapter.setClickListener(this);
        usersRecyclerView.setAdapter(userAdapter);

        addFloatingActionButton = findViewById(R.id.add_fab);
        addFloatingActionButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == addFloatingActionButton) {
            finish();
            startActivity(new Intent(getApplicationContext(), AddUserActivity.class));
        }
    }

    @Override
    public void onItemClick(View view, int position) {


        if (view.getId() == R.id.btn_edit) {
            Intent intent = new Intent(getApplicationContext(), EditUserActivity.class);
            intent.putExtra("OBJ", userArrayList.get(position));
            startActivity(intent);
        }
        if (view.getId() == R.id.btn_delete) {
            databaseHelper.deleteUser(userArrayList.get(position));
            userArrayList = databaseHelper.getAllUser();

            userAdapter.setAdapterData(userArrayList);
            userAdapter.notifyDataSetChanged();

        }
    }
}